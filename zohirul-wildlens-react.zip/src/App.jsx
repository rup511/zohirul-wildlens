import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

const birds = [
  {
    name: "Asian Koel",
    localName: "কোকিল",
    scientificName: "Eudynamys scolopaceus",
    images: ["/images/asian-koel-1.jpg", "/images/asian-koel-2.jpg"]
  },
  {
    name: "Black Drongo",
    localName: "ফিঙে",
    scientificName: "Dicrurus macrocercus",
    images: ["/images/black-drongo-1.jpg"]
  }
];

export default function ZohirulWildLens() {
  const [search, setSearch] = React.useState("");

  const filteredBirds = birds.filter(bird =>
    bird.name.toLowerCase().includes(search.toLowerCase()) ||
    bird.localName.includes(search)
  );

  return (
    <div className="p-6 max-w-screen-xl mx-auto">
      <h1 className="text-4xl font-bold mb-6 text-center">Zohirul WildLens</h1>
      <p className="text-center mb-8 text-lg">A journey into the beauty of birds through my lens</p>

      <Input
        type="text"
        placeholder="Search birds by English or Bangla name..."
        value={search}
        onChange={e => setSearch(e.target.value)}
        className="mb-8 max-w-md mx-auto"
      />

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBirds.map(bird => (
          <Card key={bird.name} className="rounded-2xl shadow-xl">
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-1">{bird.localName} ({bird.name})</h2>
              <p className="text-sm italic text-gray-500 mb-4">{bird.scientificName}</p>
              <div className="grid grid-cols-2 gap-2">
                {bird.images.map((img, idx) => (
                  <img
                    key={idx}
                    src={img}
                    alt={bird.name}
                    className="rounded-lg h-32 w-full object-cover"
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
