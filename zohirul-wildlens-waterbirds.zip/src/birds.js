export const waterBirds = [
  {
    "localName": "পাতি সরালি",
    "englishName": "Lesser Whistling Duck",
    "scientificName": "Dendrocygna javanica",
    "images": [
      "lesser-whistling-duck-1.jpg",
      "lesser-whistling-duck-2.jpg"
    ],
    "description": "এরা জলাভূমিতে দলবদ্ধভাবে বসবাস করে। ডানায় সাদা ছোপ থাকে, ডাক খুব মিষ্টি।"
  },
  {
    "localName": "বাঁশপাতি",
    "englishName": "Purple Swamphen",
    "scientificName": "Porphyrio poliocephalus",
    "images": [
      "purple-swamphen-1.jpg",
      "purple-swamphen-2.jpg"
    ],
    "description": "চমৎকার বেগুনি-নীল পালক ও লাল ঠোঁট বিশিষ্ট। পানির ধারে ঘাসের ঝোপে দেখা যায়।"
  }
];