import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { waterBirds } from "./birds";

export default function ZohirulWildLens() {
  const [search, setSearch] = React.useState("");

  const filteredBirds = waterBirds.filter(bird =>
    bird.englishName.toLowerCase().includes(search.toLowerCase()) ||
    bird.localName.includes(search)
  );

  return (
    <div className="p-6 max-w-screen-xl mx-auto">
      <h1 className="text-4xl font-bold mb-4 text-center">Zohirul WildLens</h1>
      <p className="text-center mb-8 text-lg">জলচর পাখিদের ভুবনে স্বাগতম</p>

      <Input
        type="text"
        placeholder="Search by English or Bangla name..."
        value={search}
        onChange={e => setSearch(e.target.value)}
        className="mb-8 max-w-md mx-auto"
      />

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBirds.map((bird, idx) => (
          <Card key={idx} className="rounded-2xl shadow-xl">
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-1">{bird.localName} ({bird.englishName})</h2>
              <p className="text-sm italic text-gray-500 mb-2">{bird.scientificName}</p>
              <p className="mb-4 text-sm">{bird.description}</p>
              <div className="grid grid-cols-2 gap-2">
                {bird.images.map((img, i) => (
                  <img
                    key={i}
                    src={"/images/" + img}
                    alt={bird.englishName}
                    className="rounded-lg h-32 w-full object-cover"
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
